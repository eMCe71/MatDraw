export const CONFIG={mode:'api',apiBase:'./api/index.php'};
